#include <Novice.h>
#define _USE_MATH_DEFINES
#include <math.h>
#include <stdio.h>
#include <time.h>

// BlendMode blendMode = kBlendModeNormal;

typedef struct Vector2 {
	int x;
	int y;
} Vector2;

typedef struct Player {
	Vector2 pos;
	int width;
	int height;
} Player;

typedef struct Bullet {
	Vector2 pos;
	int width;
	int height;
	int speed;
	int isShot;
} Bulolet;

const char kWindowTitle[] = "LC1C_17_タニタ_カイセイ_描画関数";

// Windowsアプリでのエントリーポイント(main関数)
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {

	// ライブラリの初期化
	Novice::Initialize(kWindowTitle, 1280, 720);

	// キー入力結果を受け取る箱
	char keys[256] = {0};
	char preKeys[256] = {0};

	/*======================================================
	乱数の処理
	======================================================*/
	unsigned int currenTime = static_cast<unsigned int>(time(nullptr));

	// 乱数を初期化
	srand(currenTime);

	Player player;
	player.pos.x = 0;
	player.pos.y = 0;
	player.width = 32;
	player.height = 32;

	// unsigned int color = 0xFFFFFFFF;

	Bullet bullet[300];
	for (int i = 0; i < 300; i++) {
		bullet[i].pos.x = player.pos.x - player.width / 2;
		bullet[i].pos.y = player.pos.y - player.height / 2;
		bullet[i].width = 32;
		bullet[i].height = 32;
		bullet[i].isShot = false;
	}

	int coolTime = 10;

	int speed = 10;

	// ウィンドウの×ボタンが押されるまでループ
	while (Novice::ProcessMessage() == 0) {
		// フレームの開始
		Novice::BeginFrame();

		// キー入力を受け取る
		memcpy(preKeys, keys, 256);
		Novice::GetHitKeyStateAll(keys);

		///
		/// ↓更新処理ここから
		///

		Novice::GetMousePosition(&player.pos.x, &player.pos.y);

		if (keys[DIK_W]) {
			player.height += 2;
		}

		if (keys[DIK_A]) {
			player.width -= 2;
		}

		if (keys[DIK_S]) {
			player.height -= 2;
		}

		if (keys[DIK_D]) {
			player.width += 2;
		}

		for (int i = 0; i < 300; i++) {
			if (coolTime <= 0) {
				if (!bullet[i].isShot) {
					bullet[i].isShot = true;
					bullet[i].pos.x = player.pos.x + rand() % (player.width * 2 + 1) - player.width;
					bullet[i].pos.y = player.pos.y + rand() % (player.height * 2 + 1) - player.height;
					coolTime = 10;
					break;
				}
			}
		}

		if (coolTime >= 0) {
			coolTime--;
		}

		for (int i = 0; i < 300; i++) {
			if (!bullet[i].isShot) {
				bullet[i].isShot = true;
			}

			if (bullet[i].isShot) {
				bullet[i].pos.y += speed;
			}
			if (bullet[i].pos.y > 720) {
				bullet[i].isShot = false;
			}
		}

		///
		/// ↑更新処理ここまで
		///

		///
		/// ↓描画処理ここから
		///

		Novice::DrawLine(640, 0, 640, 720, WHITE);

		Novice::DrawLine(0, 360, 1280, 360, WHITE);

		Novice::DrawBox(0, 0, 1280, 720, 0.0f, BLACK, kFillModeSolid);

		Novice::DrawBox(player.pos.x - player.width / 2, player.pos.y - player.height / 2, player.width, player.height, 0.0f, WHITE, kFillModeWireFrame);

		for (int i = 0; i < 300; i++) {
			Novice::DrawBox(bullet[i].pos.x, bullet[i].pos.y, bullet[i].width, bullet[i].height, 0.0f, WHITE, kFillModeSolid);
		}

		Novice::ScreenPrintf(0, 0, "WASD パーティクル発生範囲\n");
		Novice::ScreenPrintf(0, 20, "パーティクルは重力落下のみ");

		///
		/// ↑描画処理ここまで
		///

		// フレームの終了
		Novice::EndFrame();

		// ESCキーが押されたらループを抜ける
		if (preKeys[DIK_ESCAPE] == 0 && keys[DIK_ESCAPE] != 0) {
			break;
		}
	}

	// ライブラリの終了
	Novice::Finalize();
	return 0;
}
